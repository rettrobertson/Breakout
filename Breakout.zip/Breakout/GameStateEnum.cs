﻿namespace Breakout
{
    public enum GameStateEnum
    {
        MainMenu,
        GamePlay,
        HighScores,
        Options,
        Help,
        About,
        Exit, 
        Pause
    }
}
