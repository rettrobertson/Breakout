﻿namespace Breakout.GamePlay
{
    // static class for balls' bounds
    public static class Box
    {
        public static int x1;
        public static int x2;
        public static int y1;
        public static int y2;
    }
}
